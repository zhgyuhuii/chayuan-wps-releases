const a="document",i="wedding",e=n=>({group:"analysis",domain:i,modelType:"chat",defaultModelCategory:"chat",supportsRibbon:!1,defaultDisplayLocations:["ribbon-more"],defaultInputSource:a,defaultOutputFormat:"markdown",temperature:.5,...n}),o=Object.freeze([e({id:"analysis.wed-plan",label:"婚礼策划方案",shortLabel:"婚礼策划",icon:"💍",tags:["婚庆","生成","策划"],allowedActions:["insert","append","none"],defaultAction:"insert",description:"把新人需求搭成婚礼策划方案:主题风格、流程、场地布置、预算框架、分工与时间表。",systemPrompt:"你是一位资深婚礼策划师,产出落地、有创意的策划方案。基于给定需求,预算项目化(数字【待报价】),不编造供应商。",userPromptTemplate:`请把下面需求搭成婚礼策划方案:主题与风格、整体流程(仪式/宴会)、场地与布置创意、音乐与互动、预算框架(数字【待报价】)、筹备时间表与分工。
需求:
---
{{input}}
---`}),e({id:"analysis.wed-emcee",label:"司仪主持词",shortLabel:"司仪主持词",icon:"🎤",tags:["婚庆","生成","主持"],allowedActions:["insert","append","replace","none"],defaultAction:"insert",temperature:.6,description:"根据新人故事写婚礼主持词:开场、入场、仪式各环节串词,温暖有感染力不俗套。",systemPrompt:"你是一位金牌婚礼司仪,写温暖、有感染力、不油腻的主持词。只用给定的新人信息,不虚构故事细节。",userPromptTemplate:`请根据下面新人信息写婚礼主持词:开场暖场、新人入场、证婚/交换戒指/誓言、父母环节、敬酒祝福、收尾。温暖真诚、有节奏。
新人信息:
---
{{input}}
---`}),e({id:"analysis.wed-timeline",label:"婚礼流程单",shortLabel:"婚礼流程单",icon:"🗓️",tags:["婚庆","生成","流程"],allowedActions:["insert","append","comment","none"],defaultAction:"comment",temperature:.3,description:"把婚礼安排排成详细流程单(timeline):时间、环节、负责人、物料与备注,便于执行。",systemPrompt:"你是一位婚礼督导,排清晰可执行的流程单。时间照给定信息,节点衔接合理,关键环节标提醒。",userPromptTemplate:`请把下面婚礼安排排成流程单,表格:时间 | 环节 | 负责人 | 所需物料 | 备注。从化妆到送客全程,衔接合理、留缓冲。
婚礼安排:
---
{{input}}
---`}),e({id:"analysis.wed-invitation",label:"婚礼邀请函",shortLabel:"婚礼邀请函",icon:"✉️",tags:["婚庆","生成","邀请"],allowedActions:["insert","append","replace","none"],defaultAction:"insert",description:"写温馨得体的婚礼邀请函:新人、时间地点、敬邀语、回执提示,可中式或现代风。",systemPrompt:"你是一位婚礼文案,写温馨得体的邀请函。时间地点照给定信息,缺则【待补充】,不编造。",userPromptTemplate:`请根据下面信息写婚礼邀请函(给中式典雅与现代温馨两版):新人姓名、婚礼时间地点、敬邀语、着装/回执提示。缺则【待补充】。
信息:
---
{{input}}
---`}),e({id:"analysis.wed-vows",label:"结婚誓词",shortLabel:"结婚誓词",icon:"💌",tags:["婚庆","生成","誓词"],allowedActions:["insert","append","replace","none"],defaultAction:"insert",temperature:.6,description:"根据新人故事写真挚个性化的结婚誓词,具体走心不套路,可给两人各一版。",systemPrompt:"你是一位婚礼文案,写真挚、个性化的誓词。只用给定的两人故事与承诺,具体走心,不堆华丽空话。",userPromptTemplate:`请根据下面新人故事写结婚誓词:用具体的两人细节、真挚的承诺、走心不煽情。可给新郎/新娘各一版。
新人故事:
---
{{input}}
---`}),e({id:"analysis.wed-thanks",label:"答谢词",shortLabel:"答谢词",icon:"🙏",tags:["婚庆","生成","答谢"],allowedActions:["insert","append","replace","none"],defaultAction:"insert",temperature:.5,description:"写婚礼答谢词:感谢宾客与父母、表达喜悦与承诺,真诚得体不冗长,可新人或父亲版。",systemPrompt:"你是一位婚礼文案,写真诚得体的答谢词。基于给定信息,感谢具体、情感真实、控制长度。",userPromptTemplate:`请根据下面信息写婚礼答谢词:感谢到场宾客、感谢双方父母、表达对彼此的承诺、祝福收尾。给新人版与父亲致辞版各一。真诚不冗长。
信息:
---
{{input}}
---`}),e({id:"analysis.wed-budget",label:"婚礼预算整理",shortLabel:"婚礼预算",icon:"💰",tags:["婚庆","整理","预算"],allowedActions:["comment","append","insert","none"],defaultAction:"comment",temperature:.15,description:"把婚礼花费整理成预算清单:分项、金额、占比与合计,提示易超支项,数字照原文。",systemPrompt:"你是一位婚礼管家,整理清晰的预算清单。金额照原文,合计与占比先列原文数字,提示常见易漏与超支项。",userPromptTemplate:`请把下面婚礼花费整理成预算清单,表格:项目 | 预算金额 | 占比 | 备注。给合计(先列原文数字)、易漏项(三金/车队/答谢宴)与控费建议。
花费信息:
---
{{input}}
---`}),e({id:"analysis.wed-vendor-contract",label:"婚庆供应商合同审查",shortLabel:"婚庆合同审查",icon:"📑",tags:["婚庆","核查","合同"],allowedActions:["comment","link-comment","append","none"],defaultAction:"comment",temperature:.15,description:"审查婚庆/酒店/摄影等供应商合同对新人不利之处:档期变更、退改、加价、成片交付等。",systemPrompt:"你是一位婚庆消费法务,审查供应商合同对新人的风险。命中片段原文逐字、反引号包裹;不确定标「待人工核实」;不替代律师。",userPromptTemplate:`请审查下面婚庆供应商合同,关注:档期与人员是否锁定、临时换人/加价、定金与退改、成片/底片交付时间与归属、超时费、违约责任是否对等。
## 风险/不利条款 (若无写"未发现明显问题")
- 命中片段:\`原文逐字片段\`
- 问题:
- 建议:
合同:
---
{{input}}
---`}),e({id:"analysis.wed-checklist",label:"物料签到清单",shortLabel:"物料清单",icon:"✅",tags:["婚庆","生成","清单"],allowedActions:["insert","append","comment","none"],defaultAction:"comment",temperature:.2,description:"生成婚礼物料与签到清单:迎宾、仪式、宴会各环节所需物料、数量与负责人,防遗漏。",systemPrompt:"你是一位婚礼督导,生成完整物料清单。基于给定规模列项,数量提示按宾客数核对,防遗漏。",userPromptTemplate:`请根据下面婚礼信息生成物料与签到清单:迎宾区、仪式区、宴会区、新人用品、应急包,各列物料/数量/负责人/到位时间。
婚礼信息:
---
{{input}}
---`}),e({id:"analysis.wed-copy",label:"婚礼文案",shortLabel:"婚礼文案",icon:"📝",tags:["婚庆","生成","文案"],allowedActions:["insert","append","replace","none"],defaultAction:"insert",temperature:.6,description:"写婚礼相关文案:大屏标语、签到册寄语、朋友圈官宣、迎宾牌等,温馨有创意。",systemPrompt:"你是一位婚礼文案,写温馨有创意的婚礼文字。只用给定信息,真诚不俗套。",userPromptTemplate:`请根据下面信息写婚礼文案(各给2-3条):大屏/迎宾标语、签到册寄语、朋友圈官宣、桌卡/指引语。温馨有梗不俗套。
信息:
---
{{input}}
---`}),e({id:"analysis.wed-couplet",label:"婚礼对联祝词",shortLabel:"对联祝词",icon:"🏮",tags:["婚庆","生成","对联"],allowedActions:["insert","comment","append","none"],defaultAction:"insert",temperature:.6,description:"为婚礼写对联与祝词:工整押韵、寓意美好,可含新人姓名嵌字,传统喜庆。",systemPrompt:"你是一位擅长对联的文案,写工整、寓意美好的婚礼对联与祝词。平仄尽量工整,可嵌名,不生造。",userPromptTemplate:`请为下面婚礼写对联与祝词:给3副对联(含横批,寓意美满)、若干句祝词。可嵌入新人姓名,工整喜庆。
婚礼信息:
---
{{input}}
---`}),e({id:"analysis.wed-emergency",label:"婚礼应急预案",shortLabel:"婚礼应急",icon:"🧯",tags:["婚庆","生成","应急"],allowedActions:["insert","append","comment","none"],defaultAction:"comment",temperature:.3,description:"针对婚礼常见突发(天气、迟到、设备、醉酒等)整理应急预案与责任分工,有备无患。",systemPrompt:"你是一位资深婚礼督导,整理实用应急预案。基于给定场景,预案具体可执行、责任到人。",userPromptTemplate:`请针对下面婚礼场景整理应急预案:可能突发(天气/堵车迟到/设备故障/物料缺失/宾客醉酒/儿童哭闹)、每项的预防与处置、负责人与备用方案。
婚礼场景:
---
{{input}}
---`})]);function r(n=[]){const s=new Set(n.map(t=>t&&t.id));return[...n,...o.filter(t=>t&&!s.has(t.id))]}const l={WEDDING_BUILTIN_ASSISTANTS:o,mergeWeddingIntoBuiltins:r};export{o as WEDDING_BUILTIN_ASSISTANTS,l as default,r as mergeWeddingIntoBuiltins};
