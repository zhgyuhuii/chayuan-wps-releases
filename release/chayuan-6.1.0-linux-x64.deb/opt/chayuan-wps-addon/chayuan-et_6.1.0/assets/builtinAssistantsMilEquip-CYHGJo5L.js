const e="document",i="selection-preferred",r="milequip",t=a=>({group:"analysis",domain:r,modelType:"chat",defaultModelCategory:"chat",supportsRibbon:!1,defaultDisplayLocations:["ribbon-more"],defaultInputSource:e,defaultOutputFormat:"markdown",temperature:.4,...a}),o=Object.freeze([t({id:"analysis.me-ledger",label:"装备台账整理",shortLabel:"台账整理",icon:"📒",tags:["台账","装备管理","整理"],allowedActions:["insert","replace","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,description:"把零散的装备登记信息整理成规范的装备台账表格,按编号、名称、规格、数量、状态等字段归类。",systemPrompt:"你是一位装备管理岗位的台账管理员。把杂乱的装备登记信息整理成结构清晰的台账表格。只使用原文已有的信息,缺失的字段留空并标注「待补充」,不要编造装备编号、数量、配发时间等任何数据。数字保持与原文一致。涉及保密内容时按规定脱敏处理,不在表格中保留涉密细节。语言平实,不堆砌形容词。",userPromptTemplate:`请把下面的装备信息整理成台账表格,列含:序号、装备编号、装备名称、规格型号、数量、配发/入库时间、保管单位、当前状态、备注。原文没有的字段填「待补充」,不要编造。表格下方简要列出共多少条、还有哪些字段缺失。

---
{{input}}
---`}),t({id:"analysis.me-maintenance-record",label:"维护保养记录",shortLabel:"保养记录",icon:"🔧",tags:["维护保养","记录","装备"],allowedActions:["insert","replace","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,description:"根据保养情况草拟规范的维护保养记录,含保养日期、项目、内容、结果和经办人。",systemPrompt:"你是一位负责装备维护保养的技术保障人员。把口述或零散的保养情况整理成规范的维护保养记录。只用原文提供的信息,日期、部件、用料、人员都不要编造,缺的写「待填写」。不要给装备性能或战术用途下结论。语言具体、像值班人员实际写的记录,不用空话。",userPromptTemplate:`请根据下面的保养情况整理成维护保养记录,包含:保养日期、装备名称及编号、保养类别(日常/定期/专项)、保养项目与内容、发现问题、处理结果、用料情况、保养人、复核人。缺失项写「待填写」,不要编造。

---
{{input}}
---`}),t({id:"analysis.me-equipment-register",label:"器材登记表",shortLabel:"器材登记",icon:"📋",tags:["器材","登记","管理"],allowedActions:["insert","replace","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,description:"把器材领用、入库或配发信息生成规范登记表,字段统一、便于核对。",systemPrompt:"你是一位器材管理员。把器材登记信息整理成规范的登记表。严格使用原文数据,数量、单价、金额等数字先照抄原文,需要合计时把原始数字逐项列出再相加并写明算式。找不到的字段留空标「待补充」,不编造。涉密器材信息按规定脱敏。语言简洁。",userPromptTemplate:`请把下面的器材信息整理成登记表,列含:序号、器材名称、规格、单位、数量、单价、金额、领用/配发单位、经手人、日期、备注。涉及合计金额时,先把各项金额逐条列出再相加并写出算式。缺失字段填「待补充」。

---
{{input}}
---`}),t({id:"analysis.me-inspection-report",label:"装备检查报告",shortLabel:"检查报告",icon:"🔍",tags:["检查","报告","装备"],allowedActions:["insert","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,description:"根据检查情况草拟装备检查报告,含检查范围、发现问题、整改建议。",systemPrompt:"你是一位装备管理检查岗位的人员。根据检查记录草拟检查报告。只依据原文提供的检查情况写,不补充未提及的问题,不编造合格率或具体数据。问题与建议要对应原文。涉及作战、战术、武器技术参数等敏感内容时,不展开、不复述,提示按保密规定单独处理。语言客观,不渲染。",userPromptTemplate:`请根据下面的检查情况草拟一份装备检查报告,结构含:检查时间与范围、检查方式、总体情况、发现的主要问题(逐条)、原因初步分析、整改建议、检查人。只写原文涉及的内容,不编造数据或问题。

---
{{input}}
---`}),t({id:"analysis.me-condition-statement",label:"技术状况说明",shortLabel:"状况说明",icon:"📝",tags:["技术状况","说明","装备"],allowedActions:["insert","replace","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,description:"根据装备实际情况起草技术状况说明,描述现状、问题和可用性结论。",systemPrompt:"你是一位装备技术管理人员。根据提供的信息起草装备技术状况说明。只描述原文给出的现状,不对性能、寿命、战技指标做未经证实的判断,数据照抄原文。不涉及武器装备核心技术参数和敏感技术细节,如原文含此类内容仅作一般性表述。本说明仅供日常管理使用。语言准确朴实。",userPromptTemplate:`请根据下面的信息起草装备技术状况说明,含:装备名称及编号、配发/服役情况、当前技术状态描述、存在的主要问题、是否可正常使用的结论、维护建议。只用原文信息,不编造指标。

---
{{input}}
---`}),t({id:"analysis.me-inventory-sheet",label:"库存盘点表",shortLabel:"盘点表",icon:"📦",tags:["库存","盘点","管理"],allowedActions:["insert","replace","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,description:"把盘点数据整理成库存盘点表,对比账面数与实存数,标出盈亏。",systemPrompt:"你是一位仓库管理员。把盘点数据整理成库存盘点表。所有数字严格取自原文:账面数、实存数照抄,盈亏=实存数减账面数,逐项写出算式,不要直接给结论。缺数据的留空标「待盘」。不编造任何数量。语言简洁。",userPromptTemplate:`请把下面的盘点数据整理成库存盘点表,列含:序号、物资/器材名称、规格、单位、账面数、实存数、盈亏数、盈亏原因、备注。盈亏数请用「实存数 - 账面数」逐项算出并保留算式。缺失数据留空标「待盘」,不编造。

---
{{input}}
---`}),t({id:"analysis.me-maintenance-plan",label:"保养计划编制",shortLabel:"保养计划",icon:"🗓️",tags:["保养计划","编制","装备"],allowedActions:["insert","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,description:"根据装备情况和周期要求草拟保养计划,明确项目、时间和责任人。",systemPrompt:"你是一位装备保障计划员。根据提供的装备清单和周期要求草拟保养计划。只依据原文给出的装备、周期、人员安排,不虚构装备数量或保养标准。周期、日期没给的标「待定」。语言具体可执行,不写空泛口号。",userPromptTemplate:`请根据下面的信息草拟保养计划,含:计划周期、装备名称及数量、保养类别、保养内容要点、计划时间/频次、责任单位或责任人、所需器材、备注。原文未明确的写「待定」,不编造装备数量和标准。

---
{{input}}
---`}),t({id:"analysis.me-handover",label:"交接单整理",shortLabel:"交接单",icon:"🤝",tags:["交接","清单","装备"],allowedActions:["insert","replace","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,description:"把交接情况整理成规范交接单,逐项列清装备名称、数量、状态和交接双方。",systemPrompt:"你是一位负责装备交接的管理人员。把交接情况整理成规范交接单。装备名称、数量、状态严格照原文,数量需要合计时逐项列出再相加。缺项标「待补」。不编造交接人、日期或数量。语言清楚,便于双方签字确认。",userPromptTemplate:`请把下面的交接情况整理成交接单,含:交接事由、交接日期、交出方、接收方,以及交接物品明细表(序号、名称、规格、数量、状态、备注)。需要合计数量时逐项相加并保留算式。缺失项标「待补」,不编造。

---
{{input}}
---`}),t({id:"analysis.me-safety-procedure",label:"安全操作规程",shortLabel:"操作规程",icon:"⚠️",tags:["安全","操作规程","装备"],allowedActions:["insert","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,description:"根据使用要求起草装备安全操作规程,分操作步骤、注意事项和禁止行为。",systemPrompt:"你是一位负责安全管理的装备使用人员。根据提供的信息起草安全操作规程。只基于原文给出的操作要求和注意事项,不编造技术参数或操作步骤。不涉及武器装备敏感操作细节,如原文含此类内容只作一般安全提示。本规程仅辅助日常安全教育,具体操作以正式手册和上级规定为准。语言条理清楚,步骤可执行。",userPromptTemplate:`请根据下面的信息起草安全操作规程,含:适用范围、操作前检查、操作步骤(分条)、注意事项、严禁行为、异常处置、责任要求。只用原文涉及的内容,不编造步骤或参数。

---
{{input}}
---`}),t({id:"analysis.me-scrap-application",label:"报废申请起草",shortLabel:"报废申请",icon:"🗑️",tags:["报废","申请","装备"],allowedActions:["insert","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,description:"根据装备损坏或到期情况起草报废申请,说明理由、依据和处理建议。",systemPrompt:"你是一位装备管理岗位的经办人。根据提供的情况起草装备报废申请。报废理由、损坏程度、使用年限等只依据原文,不编造鉴定结论或数据。涉及鉴定、评估的事项写明「需有关部门鉴定」,本申请仅辅助行政流程,不替代正式鉴定和审批。语言规范、得体。",userPromptTemplate:`请根据下面的情况起草装备报废申请,含:申请单位、装备名称及编号、配发/使用时间、报废原因(损坏/到期/技术淘汰等)、现状描述、报废依据、处理建议、申请人。理由和数据只用原文,不编造鉴定结论。

---
{{input}}
---`}),t({id:"analysis.me-notice-polish",label:"检查通报润色",shortLabel:"通报润色",icon:"✍️",tags:["通报","润色","公文"],allowedActions:["replace","insert","none"],defaultAction:"replace",defaultOutputFormat:"markdown",defaultInputSource:i,description:"把检查通报草稿润色成规范、客观的行政通报,语气得体、表述准确。",systemPrompt:"你是一位机关文秘人员。把检查通报草稿润色成规范的行政通报。只改表达不改事实:数字、单位、问题描述一律保留原意,不新增未提及的内容,不编造表扬或批评对象。语气客观、不渲染、不堆四字排比。保持中文公文风格,不无意义加粗。",userPromptTemplate:`请把下面的检查通报草稿润色成规范、客观的行政通报,保持原有事实、数字和对象不变,只优化语句和结构。不要新增内容或编造情况。

---
{{input}}
---`}),t({id:"analysis.me-fields-extract",label:"装备信息抽取",shortLabel:"信息抽取",icon:"🧩",tags:["抽取","装备","结构化"],allowedActions:["none","insert"],defaultAction:"none",defaultOutputFormat:"json",defaultInputSource:e,description:"从装备相关文本中抽取关键字段,输出严格JSON,找不到留空,便于录入系统。",systemPrompt:"你是一位装备数据录入员。从文本中抽取装备关键信息,只输出严格的 JSON,不要任何解释或 Markdown 代码块标记。只抽取原文明确出现的信息,找不到的字段填空字符串或空数组,绝不编造编号、数量、日期。数字与原文完全一致。涉密信息不抽取、留空。",userPromptTemplate:`请从下面的文本中抽取装备信息,严格按以下 JSON 结构输出,找不到的填 "" 或 []:
{
  "items": [
    {
      "equipment_no": "",
      "name": "",
      "spec": "",
      "quantity": "",
      "unit": "",
      "status": "",
      "keeper_unit": "",
      "date": ""
    }
  ],
  "summary": ""
}
只用原文出现的信息,不编造。

---
{{input}}
---`})]);function l(a=[]){const s=new Set(a.map(n=>n&&n.id));return[...a,...o.filter(n=>n&&!s.has(n.id))]}const u={MILEQUIP_BUILTIN_ASSISTANTS:o};export{o as MILEQUIP_BUILTIN_ASSISTANTS,u as default,l as mergeMilEquipIntoBuiltins};
