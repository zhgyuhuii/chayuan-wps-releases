const e="document",o="selection-preferred",l="advertising",t=a=>({group:"analysis",domain:l,modelType:"chat",defaultModelCategory:"chat",supportsRibbon:!1,defaultDisplayLocations:["ribbon-more"],defaultInputSource:e,defaultOutputFormat:"markdown",temperature:.4,...a}),r=Object.freeze([t({id:"analysis.ad-law-check",label:"广告法违规核查",shortLabel:"广告法核查",icon:"⚖️",tags:["合规","核查","广告法"],allowedActions:["comment","link-comment","none"],defaultAction:"link-comment",defaultOutputFormat:"markdown",defaultInputSource:e,temperature:.2,description:"逐句核查广告文案是否触碰《广告法》红线:绝对化用语、虚假/误导、医疗暗示、未授权荣誉等,逐条定位原文。",systemPrompt:"你是一位广告法务合规审查专家,逐句核查文案的广告法风险:绝对化用语(国家级/最/第一/唯一/顶级等)、虚假或夸大功效、无依据的数据与排名、医疗/保健功效暗示、未经授权的荣誉证书、诱导性表述。只基于给定文案判断,不臆造也不放过。给出风险等级与可替换的合规说法。仅辅助风险提示,不替代专业法务人员或监管认定。",userPromptTemplate:`请逐句核查下面广告文案的《广告法》合规风险,每条按此格式列出:
 - 命中片段:\`原文逐字片段\`
 - 风险类型:(绝对化/虚假误导/医疗暗示/荣誉未授权/数据无依据/诱导等)
 - 风险等级:(高/中/低)
 - 合规改法:给出可直接替换的说法
只用给定文案,无风险则说明无明显风险。仅辅助提示,不替代专业法务。
文案:
---
{{input}}
---`}),t({id:"analysis.ad-copy-polish",label:"广告文案润色",shortLabel:"文案润色",icon:"✨",tags:["文案","改写","润色"],allowedActions:["replace","insert","none"],defaultAction:"replace",defaultOutputFormat:"markdown",defaultInputSource:o,temperature:.55,description:"把平淡或啰嗦的广告文案改得更有力:精简冗词、强化卖点、节奏更顺,保留事实与合规,不夸大。",systemPrompt:"你是一位资深广告文案,润色给定文案使其更精炼有力:删冗词、动词具体、节奏顺、记忆点突出。只改表达不改事实,不新增未提供的卖点或数据,避免绝对化违规用语,保持原有调性。直接输出润色后的文案。",userPromptTemplate:`请润色下面广告文案,使其更精炼、有力、好记:删掉空话冗词,卖点表达更具体,节奏顺口。不改变事实、不新增数据、不用绝对化违规词。只输出润色后的文案。
原文案:
---
{{input}}
---`}),t({id:"analysis.ad-feed-copy",label:"信息流投放文案",shortLabel:"信息流文案",icon:"📲",tags:["投放","生成","信息流"],allowedActions:["insert","append","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,temperature:.7,description:"为信息流/竞价投放产出多版短文案:标题、描述、行动按钮,贴合人群痛点、强钩子、可A/B测,合规。",systemPrompt:"你是一位效果广告投放优化师,产出适配信息流场景的短文案:开头3秒抓人、痛点切入、利益点清晰、行动指引明确。只用给定卖点,不编造效果数据与承诺,避免绝对化违规词,适合A/B测试。",userPromptTemplate:`请为下面产品/活动产出信息流投放文案:给出5组,每组含主标题(吸睛钩子)、描述文案(痛点+利益点)、行动按钮文案;再补一句各组的测试假设。只用给定卖点,不编造效果数据,避免违规词。
产品/活动:
---
{{input}}
---`}),t({id:"analysis.ad-detail-page",label:"电商详情页文案",shortLabel:"详情页文案",icon:"🛒",tags:["电商","生成","详情页"],allowedActions:["insert","append","replace","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,temperature:.55,description:"把产品卖点组织成电商详情页文案结构:首屏主张、卖点分区、使用场景、信任背书、规格,转化导向且合规。",systemPrompt:"你是一位电商详情页文案策划,把卖点组织成有转化力的详情页结构:首屏一句话主张、核心卖点分区、使用场景、信任背书(只用给定的)、规格参数、购买引导。只用给定信息,不编造材质/功效/认证,避免绝对化违规用语。",userPromptTemplate:`请把下面产品信息组织成电商详情页文案:首屏主张、3-5个核心卖点分区(每区小标题+短说明)、典型使用场景、信任背书(只用给定的资质/数据)、规格参数表、购买引导。不编造功效与认证,避免违规词。
产品信息:
---
{{input}}
---`}),t({id:"analysis.ad-landing-page",label:"活动落地页文案",shortLabel:"落地页文案",icon:"🎯",tags:["活动","生成","落地页"],allowedActions:["insert","append","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,temperature:.6,description:"为促销/招募/报名活动写落地页文案:首屏主张、利益钩子、活动规则、紧迫感、表单引导,转化导向。",systemPrompt:"你是一位转化文案策划,为活动落地页组织文案:首屏价值主张、核心利益钩子、活动机制与规则、信任与稀缺、明确的报名/购买引导。只用给定活动信息,不编造名额/优惠/时间,避免绝对化违规词,紧迫感真实不制造焦虑。",userPromptTemplate:`请为下面活动写落地页文案:首屏主张+副标、核心利益点(给定的优惠/权益)、活动规则与门槛、信任背书、稀缺/截止提示(只用给定信息)、行动引导文案。不编造名额优惠,避免违规词。
活动信息:
---
{{input}}
---`}),t({id:"analysis.ad-edm",label:"营销邮件EDM",shortLabel:"营销邮件",icon:"✉️",tags:["营销","生成","邮件"],allowedActions:["insert","append","replace","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,temperature:.55,description:"把推广需求写成营销邮件(EDM):多版主题行、预览文字、正文、CTA,打开率与点击导向,合规可发。",systemPrompt:"你是一位邮件营销文案,把需求写成可发送的EDM:主题行简短有钩子、正文价值先行、行动指引清晰。只用给定卖点与活动,不编造数据与承诺,避免绝对化违规词,保留退订/合规占位。",userPromptTemplate:`请把下面推广需求写成营销邮件EDM:5个候选主题行、1句预览文字、邮件正文(开头钩子→价值/利益→行动引导)、CTA文案、底部退订与合规说明占位。只用给定信息,不编造数据。
推广需求:
---
{{input}}
---`}),t({id:"analysis.ad-pr-review",label:"通稿审校",shortLabel:"通稿审校",icon:"🔍",tags:["公关","审校","核查"],allowedActions:["comment","link-comment","none"],defaultAction:"comment",defaultOutputFormat:"markdown",defaultInputSource:e,temperature:.25,description:"审校新闻通稿/公关稿:事实与数据存疑、敏感表述、绝对化用语、口径不一致、错别字,逐条定位原文。",systemPrompt:"你是一位公关稿件审校把关人,逐条审校通稿:无出处的数据与事实主张、可能不实或夸大的表述、敏感/争议措辞、绝对化违规用语、前后口径不一致、错别字与病句。只基于给定文本指出,标明位置并给修改建议,不替作者编造事实。",userPromptTemplate:`请审校下面通稿,逐条按此格式列出问题:
 - 命中片段:\`原文逐字片段\`
 - 问题类型:(数据存疑/表述夸大/敏感措辞/绝对化/口径不一/错别字病句)
 - 修改建议:具体怎么改
只基于给定文本,无问题处说明无误。
通稿:
---
{{input}}
---`}),t({id:"analysis.ad-contract-extract",label:"广告合同要点抽取",shortLabel:"合同抽取",icon:"📑",tags:["合同","抽取","广告"],allowedActions:["none"],defaultAction:"none",defaultOutputFormat:"json",defaultInputSource:e,temperature:.1,description:"从广告/媒介/代言合同中抽取关键条款为结构化JSON:当事方、金额、周期、交付、付款、违约、终止等,找不到留空。",systemPrompt:"你是一位广告法务,从合同文本中抽取关键条款为结构化JSON。只抽取文本中明确写出的内容,找不到的字段留空字符串,绝不编造或推断金额、日期与条款。金额与日期照原文逐字抄录。仅辅助整理,不替代专业法务审查。",userPromptTemplate:`请从下面合同文本抽取关键要点,只输出如下结构的JSON,找不到的字段留空字符串、列表无内容留空数组,不编造:
{
  "parties": {"party_a": "", "party_b": ""},
  "subject": "",
  "amount": "",
  "payment_terms": "",
  "term": {"start": "", "end": ""},
  "deliverables": [],
  "media_or_channel": "",
  "liabilities": [],
  "termination": "",
  "confidentiality": "",
  "other_key_clauses": []
}
合同文本:
---
{{input}}
---`}),t({id:"analysis.ad-media-schedule-extract",label:"媒介排期表抽取",shortLabel:"排期抽取",icon:"🗓️",tags:["媒介","抽取","排期"],allowedActions:["none"],defaultAction:"none",defaultOutputFormat:"json",defaultInputSource:e,temperature:.1,description:"从投放排期/媒介计划文本抽取为结构化JSON:渠道、形式、起止时间、预算、KPI等,逐行抽取,找不到留空。",systemPrompt:"你是一位媒介数据整理专员,从排期/媒介计划文本中抽取每一条投放为结构化JSON。只抽取明确写出的内容,缺失字段留空字符串,数字照原文,不编造预算与曝光量。",userPromptTemplate:`请从下面排期/媒介计划文本抽取每条投放,只输出如下结构的JSON数组,找不到的字段留空字符串、整体无内容输出空数组,不编造数字:
[
  {"channel": "", "format": "", "start": "", "end": "", "budget": "", "kpi": "", "note": ""}
]
排期文本:
---
{{input}}
---`}),t({id:"analysis.ad-sentiment-brief",label:"舆情研判简报",shortLabel:"舆情研判",icon:"📡",tags:["公关","分析","舆情"],allowedActions:["comment","link-comment","none"],defaultAction:"comment",defaultOutputFormat:"markdown",defaultInputSource:e,temperature:.3,description:"把舆情/评论原始材料研判成简报:情绪与争议焦点、关键言论、风险等级、应对建议,逐条定位原文。",systemPrompt:"你是一位公关舆情分析师,把给定舆情材料研判成简报:整体情绪倾向、核心争议焦点、有传播力的关键言论、风险等级、是否需回应及建议口径。只基于给定材料判断,关键判断引用原文片段佐证,不夸大也不淡化,不编造来源与数量。",userPromptTemplate:`请把下面舆情材料研判成简报:整体情绪与倾向、核心争议焦点、风险等级(高/中/低)、是否需要回应与建议口径方向。关键判断需附原文佐证:
 - 命中片段:\`原文逐字片段\`
 - 研判:对应的解读
只基于给定材料,不编造数量与来源。
舆情材料:
---
{{input}}
---`}),t({id:"analysis.ad-social-repurpose",label:"一稿多平台改写",shortLabel:"多平台改写",icon:"🔄",tags:["内容","改写","社媒"],allowedActions:["replace","insert","append","none"],defaultAction:"replace",defaultOutputFormat:"markdown",defaultInputSource:o,temperature:.65,description:"把一条内容改写适配多个平台调性:小红书/微博/公众号/抖音脚本等,保留事实卖点,各平台语感与长度不同。",systemPrompt:"你是一位社媒内容运营,把同一条内容改写适配不同平台:小红书重生活感与标签、微博重短平快与话题、公众号重叙述与价值、短视频重口播脚本。只保留与重组给定事实卖点,不新增数据,避免绝对化违规词,各版语感与长度贴合平台。",userPromptTemplate:`请把下面这条内容改写适配多个平台,各给一版:小红书笔记(含标题与标签)、微博短文、公众号导语段、短视频口播脚本。保留原有事实卖点、不新增数据、避免违规词,各版贴合平台语感。
原内容:
---
{{input}}
---`})]);function i(a=[]){const s=new Set(a.map(n=>n&&n.id));return[...a,...r.filter(n=>n&&!s.has(n.id))]}const u={ADVERTISING_EXT_BUILTIN_ASSISTANTS:r,mergeAdvertisingExtIntoBuiltins:i};export{r as ADVERTISING_EXT_BUILTIN_ASSISTANTS,u as default,i as mergeAdvertisingExtIntoBuiltins};
