const a="document",s="printing",e=t=>({group:"analysis",domain:s,modelType:"chat",defaultModelCategory:"chat",supportsRibbon:!1,defaultDisplayLocations:["ribbon-more"],defaultInputSource:a,defaultOutputFormat:"markdown",temperature:.3,...t}),i=Object.freeze([e({id:"analysis.print-process-spec",label:"印刷工艺说明",shortLabel:"印刷工艺说明",icon:"🖨️",tags:["印刷","生成","工艺"],allowedActions:["insert","append","none"],defaultAction:"insert",description:"把印刷需求整理成工艺说明:印刷方式、用纸、工艺、色彩、装订要求,参数照原文。",systemPrompt:"你是一位印刷工艺工程师,写规范的印刷工艺说明。用纸克重、颜色、工艺照原文,不臆造参数。",userPromptTemplate:`请把下面需求整理成印刷工艺说明:印刷方式、用纸与克重、印后工艺(覆膜/烫金/UV等)、色彩要求、装订与成品尺寸。参数照原文,缺则"待确认"。
需求:
---
{{input}}
---`}),e({id:"analysis.print-package-brief",label:"包装设计brief",shortLabel:"包装brief",icon:"📦",tags:["包装","生成","设计"],allowedActions:["insert","append","none"],defaultAction:"insert",temperature:.4,description:"把包装需求写成设计brief:产品定位、目标人群、风格、必含信息、规格与工艺约束。",systemPrompt:"你是一位包装项目经理,写清晰的设计brief。基于给定信息组织,缺项用【待补充】,不编造品牌主张。",userPromptTemplate:`请把下面包装需求写成设计brief:产品与卖点、目标人群、设计风格与调性、必含信息(成分/净含量/条码/合规标识)、规格尺寸与工艺约束、参考与禁忌。缺则【待补充】。
需求:
---
{{input}}
---`}),e({id:"analysis.print-quote",label:"印刷报价整理",shortLabel:"印刷报价",icon:"💴",tags:["印刷","整理","报价"],allowedActions:["comment","append","insert","none"],defaultAction:"comment",temperature:.15,description:"把印刷报价整理成清晰说明:工艺项、数量、单价、合计,含/不含税与版费,数字照原文。",systemPrompt:"你是一位印刷业务,把报价整理清楚透明。金额照原文,合计先列原文数字,写清含不含税与版费。",userPromptTemplate:`请把下面印刷报价整理成说明:项目明细(工艺|数量|单价|金额)、合计(先列原文数字)、含/不含税、版费/打样费、付款与交期。
报价:
---
{{input}}
---`}),e({id:"analysis.print-prepress-check",label:"印前文件检查",shortLabel:"印前检查",icon:"✅",tags:["印刷","核查","印前"],allowedActions:["comment","link-comment","append","none"],defaultAction:"comment",temperature:.15,description:"对照印前规范检查文件要点:出血、分辨率、色彩模式、字体转曲、叠印等,列出隐患。",systemPrompt:"你是一位印前技术员,检查印前文件隐患。涉及具体处引原文逐字、反引号包裹;只标真问题。",userPromptTemplate:`请对照印前规范检查下面文件说明,关注:出血是否留够、分辨率(300dpi)、色彩模式(CMYK)、专色、字体是否转曲、小字反白、叠印陷印、刀版与安全边距。
## 隐患 (若无写"未发现明显隐患")
- 命中片段:\`原文逐字片段\`
- 隐患:
- 建议:
文件说明:
---
{{input}}
---`}),e({id:"analysis.print-material-spec",label:"纸张材料说明",shortLabel:"纸张材料说明",icon:"📄",tags:["印刷","生成","材料"],allowedActions:["insert","append","comment","none"],defaultAction:"comment",temperature:.2,description:"把纸张/材料信息整理成说明:种类、克重、特性、适用场景与手感效果,客观不夸大。",systemPrompt:"你是一位纸张材料顾问,客观说明材料特性与适用。只用给定信息,不夸大环保/质感。",userPromptTemplate:`请把下面纸张/材料整理成说明:名称种类、克重、表面与手感特性、印刷适性、适用场景、注意事项。客观照原文。
材料信息:
---
{{input}}
---`}),e({id:"analysis.print-contract-review",label:"印刷合同审查",shortLabel:"印刷合同审查",icon:"📑",tags:["印刷","核查","合同"],allowedActions:["comment","link-comment","append","none"],defaultAction:"comment",temperature:.15,description:"审查印刷/加工合同:质量标准、色差与损耗、交期违约、版权与样稿确认、付款等风险。",systemPrompt:"你是一位印刷业务法务,审查合同风险。命中片段原文逐字、反引号包裹;不确定标「待人工核实」;不替代律师。",userPromptTemplate:`请审查下面印刷合同,关注:质量与色差标准、合理损耗、交期与违约、改稿与签样确认责任、版权与内容合规归属、付款与结算。
## 风险/不利条款 (若无写"未发现明显问题")
- 命中片段:\`原文逐字片段\`
- 问题:
- 建议:
合同:
---
{{input}}
---`}),e({id:"analysis.print-schedule",label:"生产排期",shortLabel:"生产排期",icon:"🗓️",tags:["印刷","生成","排期"],allowedActions:["insert","append","comment","none"],defaultAction:"comment",temperature:.2,description:"把订单要点排成生产计划:设计、打样、印刷、印后、交付各节点与负责人,工期照原文。",systemPrompt:"你是一位印刷生产调度,排合理生产计划。工期节点照原文,不臆造产能,关键节点标风险。",userPromptTemplate:`请把下面订单排成生产计划:各工序节点(设计/打样确认/印刷/印后/质检/交付)、时间、负责方、依赖与风险点。工期照原文。
订单要点:
---
{{input}}
---`}),e({id:"analysis.print-confirm-order",label:"客户确认单整理",shortLabel:"确认单整理",icon:"📝",tags:["印刷","整理","确认"],allowedActions:["insert","append","comment","none"],defaultAction:"comment",temperature:.15,description:"把订单要素整理成客户确认单:规格、工艺、数量、颜色、价格、交期,供签字确认防纠纷。",systemPrompt:"你是一位印刷客服,整理完整的客户确认单。要素照原文,逐项可核对,留签字确认位。",userPromptTemplate:`请把下面订单整理成客户确认单:产品名、规格尺寸、用纸、印刷与印后工艺、颜色、数量、单价合计、交期、特别约定、客户签字确认位。照原文。
订单:
---
{{input}}
---`}),e({id:"analysis.print-spec-extract",label:"印刷规格提取",shortLabel:"规格提取",icon:"🗂️",tags:["印刷","提取","规格"],allowedActions:["comment","none"],defaultAction:"none",defaultOutputFormat:"json",temperature:.1,description:"从需求/订单提取印刷规格参数,输出结构化便于报价与排产。",systemPrompt:"你是一位印刷业务,从订单抽取规格,输出严格 JSON,尺寸数量照原文,找不到留空。",userPromptTemplate:`请从下面订单提取规格,输出严格 JSON:
{"product":"","size":"","paper":"","weight":"","color":"","printSides":"","finishing":[],"binding":"","quantity":""}
订单:
---
{{input}}
---`}),e({id:"analysis.print-package-copy",label:"包装文案",shortLabel:"包装文案",icon:"🎁",tags:["包装","生成","文案"],allowedActions:["insert","append","replace","none"],defaultAction:"insert",temperature:.5,description:"为包装写文案:主视觉slogan、卖点短句、产品说明、必含合规信息提示,合规不夸大。",systemPrompt:"你是一位包装文案,写有质感、合规的包装文字。只用真实信息,不编造功效,提醒必含合规标识。",userPromptTemplate:`请为下面产品写包装文案:正面slogan、卖点短句、背面产品说明、必含合规信息提示(成分/净含量/厂商/标准号)。合规不夸大。
产品信息:
---
{{input}}
---`}),e({id:"analysis.print-quality-standard",label:"印刷质量标准",shortLabel:"质量标准",icon:"📐",tags:["印刷","生成","质量"],allowedActions:["insert","append","comment","none"],defaultAction:"comment",temperature:.2,description:"制定印刷品收货质量标准:色差、套准、刀工、装订、外观缺陷判定与抽检方式。",systemPrompt:'你是一位印刷质检,制定可操作的质量标准。基于给定产品列检验项与判定,不臆造行业限值,标"以协议为准"。',userPromptTemplate:`请为下面印刷品制定收货质量标准:色差范围、套准精度、裁切刀工、覆膜/装订、外观缺陷(脏点/划痕/折痕)判定、抽检比例与拒收情形。具体限值标"以双方协议为准"。
产品:
---
{{input}}
---`}),e({id:"analysis.print-delivery",label:"交付说明",shortLabel:"交付说明",icon:"🚚",tags:["印刷","生成","交付"],allowedActions:["insert","append","replace","none"],defaultAction:"insert",temperature:.2,description:"把交付安排写成说明:数量、包装、物流、收货验收、对账与售后联系,清楚得体。",systemPrompt:"你是一位印刷客服,写清楚的交付说明。数量时间照原文,验收与售后写清,不承诺未确认时效。",userPromptTemplate:`请把下面交付安排写成说明:成品数量与包装、物流与预计到达、收货验收要点、对账与发票、售后联系方式。照原文,缺则【待补充】。
交付安排:
---
{{input}}
---`})]);function r(t=[]){const o=new Set(t.map(n=>n&&n.id));return[...t,...i.filter(n=>n&&!o.has(n.id))]}const p={PRINTING_BUILTIN_ASSISTANTS:i,mergePrintingIntoBuiltins:r};export{i as PRINTING_BUILTIN_ASSISTANTS,p as default,r as mergePrintingIntoBuiltins};
