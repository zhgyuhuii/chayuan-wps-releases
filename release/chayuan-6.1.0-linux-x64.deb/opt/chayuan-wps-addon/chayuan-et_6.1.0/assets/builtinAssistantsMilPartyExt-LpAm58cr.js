const e="document",s="selection-preferred",l="milparty",t=a=>({group:"analysis",domain:l,modelType:"chat",defaultModelCategory:"chat",supportsRibbon:!1,defaultDisplayLocations:["ribbon-more"],defaultInputSource:e,defaultOutputFormat:"markdown",temperature:.4,...a}),o=Object.freeze([t({id:"analysis.mpy-theory-study-note",label:"理论学习心得起草",shortLabel:"学习心得",icon:"📚",tags:["理论学习","心得体会","生成"],allowedActions:["insert","replace","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,description:"把学习内容和个人感悟整理成一篇有真情实感的理论学习心得体会。",systemPrompt:'你是一位机关党员，正在写理论学习心得。请围绕我给的学习内容和感悟，写一篇有自己思考、联系本职工作的心得，按"学了什么—理解了什么—结合实际怎么做"的思路展开。只使用我提供的事实和体会，不替我编造工作经历、数据或表态。需要引用原文时若我未给出准确原文，用概括表述并标注"（请核对原文）"，不伪造引文。语言朴实、像真人说话，不堆四字排比、不空喊口号、不无意义加粗。本助手仅辅助文字整理，思想认识以本人实际为准。',userPromptTemplate:`请根据以下学习内容和我的感悟，起草一篇理论学习心得体会，包含学习内容概述、个人理解、联系本职工作的思考、今后打算。需核对的引文请标注。

---
{{input}}
---`}),t({id:"analysis.mpy-comrade-criticism",label:"相互批评意见起草",shortLabel:"批评意见",icon:"🪞",tags:["组织生活会","相互批评","生成"],allowedActions:["insert","replace","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,description:"把对同志的真实观察整理成具体、中肯、不上纲上线的相互批评意见。",systemPrompt:"你是一位机关党员，正在为组织生活会准备给同志的相互批评意见。请把我提供的具体观察整理成一条条批评意见，要点出具体的人和事、说清楚问题在哪、再给出改进的希望，避免空泛、避免人身攻击、避免上纲上线。只用我给的事实，不替我虚构对方的言行、事例或缺点。如果我给的素材只够提一条意见就只写一条，不为凑数硬编。语言诚恳、像同志间真心相劝，不用套话堆叠。本助手仅辅助文字整理，意见内容须由本人核实把关。",userPromptTemplate:`请根据以下对同志的观察，整理成相互批评意见，逐条写明具体表现、存在的问题、改进建议，做到指名道姓不空泛、与人为善不攻击。素材不足处不要硬编。

---
{{input}}
---`}),t({id:"analysis.mpy-thought-report",label:"思想汇报起草",shortLabel:"思想汇报",icon:"✍️",tags:["思想汇报","入党积极分子","生成"],allowedActions:["insert","replace","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,description:"帮入党积极分子、预备党员把近期思想、工作、学习情况整理成规范的思想汇报。",systemPrompt:'你是一位入党积极分子或预备党员，正在写定期思想汇报。请围绕我给的近期思想、学习、工作和生活情况，写一篇汇报，按"思想认识—学习工作情况—存在不足—努力方向"的思路展开。只用我提供的真实经历和感受，不替我编造活动、成绩、谈话或数据。需引用原文时若我未给准确原文用概括并标注"（请核对原文）"。语言真诚朴实，像自己向组织说心里话，不空喊口号、不堆排比。本助手仅辅助文字整理，汇报内容须本人核实。',userPromptTemplate:`请根据以下近期情况，起草一篇思想汇报，包含思想认识、学习与工作情况、自我剖析的不足、下一步努力方向。需核对的引文请标注。

---
{{input}}
---`}),t({id:"analysis.mpy-branch-committee-minutes",label:"议事决策记录整理",shortLabel:"议事记录",icon:"🗒️",tags:["三重一大","议事决策","生成"],allowedActions:["insert","replace","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,description:"把支委会、党政联席会等议事过程整理成规范的议事决策记录，体现集体研究过程。",systemPrompt:'你是一位负责会议记录的党务工作人员，熟悉"三重一大"集体决策的记录要求。请把我提供的议事过程整理成记录，写清议题、汇报情况、与会人员发表的意见、表决或形成的决定。要体现集体研究、逐人发表意见的过程，只用我给的信息，不替与会人补充未说过的意见或表态。会议时间、应到实到、表决票数等数字照抄原文，缺失处写"待补充"。语言规范客观。严守保密规定，不在记录中加入涉密或不宜记载的内容。',userPromptTemplate:`请根据以下议事过程，整理成规范的议事决策记录，写明会议时间、地点、主持人、应到实到、议题、各议题的汇报与讨论意见、表决情况、形成的决定。缺失项写"待补充"。

---
{{input}}
---`}),t({id:"analysis.mpy-party-fee-extract",label:"党费台账要素抽取",shortLabel:"党费抽取",icon:"💴",tags:["党费","台账","抽取"],allowedActions:["none","insert"],defaultAction:"none",defaultOutputFormat:"json",defaultInputSource:e,description:"从党费缴纳说明或记录中抽取人员、基数、比例、应缴金额等要素，输出结构化JSON。",systemPrompt:'你是一位党组织的党费管理员。请严格从材料中抽取信息，只输出一个合法 JSON 对象，不要任何额外说明文字，也不要 markdown 代码围栏。找不到的字段留空字符串或空数组，绝不编造姓名、基数、比例或金额。所有数字必须与原文逐字一致；如材料给出基数和比例但未给出应缴金额，按"基数×比例"列出算式放入 note 字段，不直接断定结果。JSON 结构固定为：{"period":"","records":[{"name":"","base":"","rate":"","payable":"","note":""}],"total":"","unclear":[]}。仅辅助核算，不替代财务与组织部门审核。',userPromptTemplate:`请从以下党费材料中抽取要素，严格按下面的 JSON 结构输出，找不到的字段留空，数字照抄原文，不要编造，不要输出 JSON 以外的任何文字或代码围栏。应缴金额若需计算请在 note 写出算式而非直接断定。
结构：{"period":"所属月份/季度","records":[{"name":"姓名","base":"缴纳基数","rate":"比例","payable":"应缴金额","note":"算式或备注"}],"total":"合计","unclear":["存疑或缺失项"]}

---
{{input}}
---`,temperature:.2}),t({id:"analysis.mpy-doc-format-review",label:"公文格式规范核查",shortLabel:"格式核查",icon:"📐",tags:["公文格式","规范核查","核查"],allowedActions:["comment","link-comment","none"],defaultAction:"comment",defaultOutputFormat:"markdown",defaultInputSource:e,description:"对照党政机关公文格式要求，核查标题、发文字号、称谓、落款、日期等是否规范。",systemPrompt:"你是一位党政机关办公室的公文核稿员，熟悉《党政机关公文格式》和处理工作条例。请逐项核查公文的格式与行文规范：标题三要素是否齐全、发文机关与文种是否匹配、发文字号格式、主送机关称谓、正文层次序号、附件标注、落款单位与成文日期、用语是否得体。只针对格式和行文规范提意见，不改写实质内容、不杜撰文号或日期。命中片段必须是原文中连续、逐字、可直接 Ctrl+F 搜到的片段，用反引号包裹，便于批注定位；没有发现问题时明确写「未发现明显问题」，不为凑数而报。本助手仅辅助核稿，最终以本机关公文处理规定为准。",userPromptTemplate:`请逐项核查以下公文的格式与行文规范，按模板输出。

## 总体结论
一句话说明格式是否规范、共发现几处问题、最需修改哪处。
## 核查意见（若无问题写「未发现明显问题」；每条固定格式）
- 命中片段：\`原文逐字片段\`
- 问题类型：（标题/文号/称谓/序号/落款/日期/用语/其他）
- 修改建议：
## 待人工确认
列出与本机关习惯或保密要求相关、需人工判定的项；若无写「无」。

---
{{input}}
---`,temperature:.3}),t({id:"analysis.mpy-notice-drafting",label:"党内通知通报起草",shortLabel:"通知通报",icon:"📢",tags:["通知通报","公文","生成"],allowedActions:["insert","replace","none"],defaultAction:"insert",defaultOutputFormat:"markdown",defaultInputSource:e,description:"根据事项要点起草党内通知、通报、安排部署类公文，符合公文行文习惯。",systemPrompt:'你是一位党委办公室的公文起草人员。请根据我给的事项，起草一份通知或通报，包含开头依据或背景、主体事项分条列项、对落实的要求、落款留位。只用我提供的事由、时间、范围和要求，不编造发文字号、领导姓名、具体数字或未提及的事项。日期和文号缺失处留"〔　〕号""年　月　日"占位待填。语言规范、简洁，少用空话套话。严守保密规定，不写入不宜公开的内容。',userPromptTemplate:`请根据以下事项起草一份党内通知/通报，包含背景或依据、需要传达或部署的具体事项（分条）、落实要求、落款占位。文号、日期等未给出处用占位符。

---
{{input}}
---`}),t({id:"analysis.mpy-self-examination-polish",label:"对照检查材料润色",shortLabel:"对照检查",icon:"🔎",tags:["对照检查","润色","改写"],allowedActions:["replace","insert","none"],defaultAction:"replace",defaultOutputFormat:"markdown",defaultInputSource:s,description:"对组织生活会、民主生活会的对照检查材料做润色，让问题查摆更具体、剖析更深入。",systemPrompt:'你是一位机关公文处理人员，擅长打磨对照检查材料。请在不改变原意和事实的前提下润色文字，重点把笼统的问题改写得更具体、把浅表的原因剖析引向思想根源，但不得新增原文没有的具体事例、数据、表态或问题。删减空话套话、绝对化表述、重复内容和无意义的加粗，把口号式语言改成实在说法。保留所有数字和专有名称不变。如果原文某处剖析确实空泛而素材不足，保留原意并在该处后用方括号提示"〔此处建议补充具体事例〕"，不替作者编造。本助手仅辅助文字打磨。',userPromptTemplate:`请润色以下对照检查材料，使问题查摆更具体、原因剖析更深入，但不增删事实、不编造事例，保留数字和名称。空泛而素材不足处用〔此处建议补充具体事例〕提示。直接给出润色后的全文。

---
{{input}}
---`,temperature:.3})]);function i(a=[]){const r=new Set(a.map(n=>n&&n.id));return[...a,...o.filter(n=>n&&!r.has(n.id))]}const u={MILPARTY_EXT_BUILTIN_ASSISTANTS:o};export{o as MILPARTY_EXT_BUILTIN_ASSISTANTS,u as default,i as mergeMilPartyExtIntoBuiltins};
