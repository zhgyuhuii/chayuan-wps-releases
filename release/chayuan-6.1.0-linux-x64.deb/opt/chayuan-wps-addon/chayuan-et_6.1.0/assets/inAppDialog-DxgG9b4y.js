const v="in-app-dialog-styles",h="in-app-dialog-container";function S(){if(typeof document=="undefined"||document.getElementById(v))return;const e=document.createElement("style");e.id=v,e.textContent=`
    .${h} {
      position: fixed; inset: 0; pointer-events: none;
      z-index: 2147483600;
    }
    /*
     * Overlay 在 WPS WebView 里只做"截获背景点击"用,不再做大面积压暗。
     * 之前 rgba(15,23,42,0.42)+blur 在 WPS 内嵌 WebView(尤其不支持 backdrop-filter
     * 的旧版本)看起来像把整个设置窗口"隐藏"了。改成几乎透明的微暗,让用户
     * 始终能看清下面那一层(设置面板),只有 card 自身用阴影强调"模态"语义。
     */
    .in-app-dialog-overlay {
      position: fixed; inset: 0;
      background: rgba(15, 23, 42, 0.10);
      display: flex; align-items: center; justify-content: center;
      pointer-events: auto;
      opacity: 0;
      transition: opacity 0.16s ease-out;
    }
    .in-app-dialog-overlay.is-open { opacity: 1; }
    .in-app-dialog-card {
      min-width: 320px;
      max-width: min(520px, calc(100vw - 32px));
      background: #ffffff;
      border-radius: 10px;
      /* card 加重阴影,即使 overlay 接近透明也能视觉上凸出 */
      box-shadow: 0 28px 64px -18px rgba(15, 23, 42, 0.55),
                  0 12px 24px -10px rgba(15, 23, 42, 0.35),
                  0 0 0 1px rgba(15, 23, 42, 0.06);
      overflow: hidden;
      transform: translateY(8px) scale(0.98);
      opacity: 0;
      transition: transform 0.18s cubic-bezier(.2,.8,.4,1), opacity 0.18s ease-out;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC",
                   "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
      color: #1f2a44;
    }
    .in-app-dialog-overlay.is-open .in-app-dialog-card {
      transform: translateY(0) scale(1);
      opacity: 1;
    }
    .in-app-dialog-head {
      padding: 16px 20px 4px;
      font-size: 14.5px;
      font-weight: 600;
      letter-spacing: 0.01em;
    }
    .in-app-dialog-body {
      padding: 6px 20px 16px;
      font-size: 13.5px;
      line-height: 1.6;
      color: #344056;
      white-space: pre-wrap;
      word-break: break-word;
      max-height: min(60vh, 420px);
      overflow-y: auto;
    }
    .in-app-dialog-foot {
      display: flex;
      gap: 8px;
      justify-content: flex-end;
      padding: 10px 16px 14px;
      background: #f8fafc;
      border-top: 1px solid #eef2f7;
    }
    .in-app-dialog-btn {
      min-width: 76px;
      padding: 6px 14px;
      font-size: 13px;
      border-radius: 6px;
      border: 1px solid #d6dbe6;
      background: #ffffff;
      color: #1f2a44;
      cursor: pointer;
      transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
    }
    .in-app-dialog-btn:hover { background: #f1f5f9; }
    .in-app-dialog-btn:focus-visible {
      outline: 2px solid #2a6ddf;
      outline-offset: 1px;
    }
    .in-app-dialog-btn-primary {
      background: #2a6ddf; border-color: #2a6ddf; color: #ffffff;
    }
    .in-app-dialog-btn-primary:hover { background: #2057bd; border-color: #2057bd; }
    .in-app-dialog-btn-danger {
      background: #d04848; border-color: #d04848; color: #ffffff;
    }
    .in-app-dialog-btn-danger:hover { background: #b03a3a; border-color: #b03a3a; }
  `,document.head.appendChild(e)}function N(){S();let e=document.querySelector("."+h);return e&&document.body.contains(e)||(e=document.createElement("div"),e.className=h,document.body.appendChild(e)),e}function C(){const e=N(),t=document.createElement("div");return t.className="in-app-dialog-overlay",t.setAttribute("role","dialog"),t.setAttribute("aria-modal","true"),e.appendChild(t),requestAnimationFrame(()=>t.classList.add("is-open")),t}function w(e){!e||!e.parentNode||(e.classList.remove("is-open"),setTimeout(()=>{e&&e.parentNode&&e.parentNode.removeChild(e)},200))}function E(e,t){const r=document.createElement("button");return r.type="button",r.className="in-app-dialog-btn"+(t?" in-app-dialog-btn-"+t:""),r.textContent=String(e||""),r}function T(e,t={}){const r=String(t.title||"请确认"),b=String(t.okText||"确定"),g=String(t.cancelText||"取消"),f=t.danger?"danger":"primary";return new Promise(c=>{if(typeof document=="undefined"){c(!1);return}const p=C(),i=document.activeElement instanceof HTMLElement?document.activeElement:null;let m=!1;const a=o=>{var k;if(!m){m=!0,document.removeEventListener("keydown",u,!0),w(p);try{(k=i==null?void 0:i.focus)==null||k.call(i)}catch(L){}c(!!o)}},u=o=>{o.key==="Escape"?(o.preventDefault(),o.stopPropagation(),a(!1)):o.key==="Enter"&&(o.preventDefault(),o.stopPropagation(),a(!0))};document.addEventListener("keydown",u,!0);const d=document.createElement("div");d.className="in-app-dialog-card";const l=document.createElement("div");l.className="in-app-dialog-head",l.textContent=r;const s=document.createElement("div");s.className="in-app-dialog-body",s.textContent=String(e||"");const n=document.createElement("div");n.className="in-app-dialog-foot";const x=E(g),y=E(b,f);x.addEventListener("click",()=>a(!1)),y.addEventListener("click",()=>a(!0)),n.appendChild(x),n.appendChild(y),d.appendChild(l),d.appendChild(s),d.appendChild(n),p.addEventListener("click",o=>{o.target===p&&a(!1)}),p.appendChild(d),setTimeout(()=>{try{y.focus()}catch(o){}},30)})}function P(e,t={}){const r=String(t.title||"提示"),b=String(t.okText||"我知道了");return new Promise(g=>{if(typeof document=="undefined"){g();return}const f=C(),c=document.activeElement instanceof HTMLElement?document.activeElement:null;let p=!1;const i=()=>{var n;if(!p){p=!0,document.removeEventListener("keydown",m,!0),w(f);try{(n=c==null?void 0:c.focus)==null||n.call(c)}catch(x){}g()}},m=n=>{(n.key==="Escape"||n.key==="Enter")&&(n.preventDefault(),n.stopPropagation(),i())};document.addEventListener("keydown",m,!0);const a=document.createElement("div");a.className="in-app-dialog-card";const u=document.createElement("div");u.className="in-app-dialog-head",u.textContent=r;const d=document.createElement("div");d.className="in-app-dialog-body",d.textContent=String(e||"");const l=document.createElement("div");l.className="in-app-dialog-foot";const s=E(b,"primary");s.addEventListener("click",i),l.appendChild(s),a.appendChild(u),a.appendChild(d),a.appendChild(l),f.addEventListener("click",n=>{n.target===f&&i()}),f.appendChild(a),setTimeout(()=>{try{s.focus()}catch(n){}},30)})}export{P as a,T as i};
