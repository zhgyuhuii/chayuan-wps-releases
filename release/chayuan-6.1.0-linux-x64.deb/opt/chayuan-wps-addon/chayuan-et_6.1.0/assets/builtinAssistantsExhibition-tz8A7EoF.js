const a="document",i="selection-preferred",r="exhibition",e=n=>({group:"analysis",domain:r,modelType:"chat",defaultModelCategory:"chat",supportsRibbon:!1,defaultDisplayLocations:["ribbon-more"],defaultInputSource:a,defaultOutputFormat:"markdown",temperature:.4,...n}),o=Object.freeze([e({id:"analysis.ex-recruit-plan",label:"展会招商方案",shortLabel:"招商方案",icon:"🏛️",tags:["会展","生成","招商"],allowedActions:["insert","append","none"],defaultAction:"insert",description:"把展会信息搭成招商招展方案:展会定位、目标客户、招商政策、展位档次与价格框架、推进节奏。",systemPrompt:"你是一位资深会展招商总监,产出可落地的招商招展方案。只用给定的展会信息,价格与面积数字照原文,缺失项写【待定】,不编造客户名单与成交数据。",userPromptTemplate:`请把下面展会信息搭成招商招展方案:展会定位与卖点、目标参展商画像、招商政策(早鸟/团报/老客户优惠,数字照原文)、展位档次与单价框架、招商目标与推进节奏、对接分工。缺失项写【待定】。
展会信息:
---
{{input}}
---`}),e({id:"analysis.ex-invitation-letter",label:"参展邀请函",shortLabel:"参展邀请函",icon:"✉️",tags:["会展","生成","邀请"],allowedActions:["insert","append","replace","none"],defaultAction:"insert",description:"写正式得体的参展邀请函:展会简介、参展价值、时间地点、报名与对接方式,可对企业或行业协会。",systemPrompt:"你是一位会展招商文案,写正式得体的参展邀请函。时间地点与展会名称照给定信息,缺则【待补充】,不夸大观众量与成交效果。",userPromptTemplate:`请根据下面信息写参展邀请函:展会简介、参展核心价值、时间与地点、参展形式与报名方式、联系人对接。给「致企业」与「致行业协会」两版。缺失信息写【待补充】,不夸大数据。
信息:
---
{{input}}
---`}),e({id:"analysis.ex-attendee-invite",label:"观众邀约文案",shortLabel:"观众邀约",icon:"🎟️",tags:["会展","生成","观众"],allowedActions:["insert","append","replace","none"],defaultAction:"insert",temperature:.6,description:"写专业观众预登记邀约文案:看点、亮点同期活动、参观价值与预登记入口,用于短信、邮件、社群。",systemPrompt:"你是一位会展观众运营,写吸引专业观众预登记的邀约文案。只用给定看点,不虚构展商品牌与同期活动,语气专业不浮夸。",userPromptTemplate:`请根据下面信息写观众预登记邀约文案,各给2-3条:短信版、邮件版、社群/朋友圈版。突出看点、同期活动、参观价值与预登记入口。只用给定信息,不虚构展商。
信息:
---
{{input}}
---`}),e({id:"analysis.ex-exhibitor-manual",label:"展商手册编写",shortLabel:"展商手册",icon:"📘",tags:["会展","生成","手册"],allowedActions:["insert","append","none"],defaultAction:"insert",temperature:.3,description:"编写展商手册核心内容:布撤展时间、展位规则、搭建报审、用电用水、安全消防与各类截止时间。",systemPrompt:"你是一位会展运营主管,编写清晰准确的展商手册。时间节点与规则照给定信息,缺则【待主办确认】,不杜撰收费标准与场馆规定。",userPromptTemplate:`请根据下面信息编写展商手册核心章节:进场与布展时间、展位使用规则、特装搭建报审与押金、用电用水申请、撤展时间、安全消防要求、各项截止时间一览。缺失写【待主办确认】。
信息:
---
{{input}}
---`}),e({id:"analysis.ex-operation-plan",label:"现场运营方案",shortLabel:"运营方案",icon:"🎪",tags:["会展","生成","运营"],allowedActions:["insert","append","none"],defaultAction:"insert",description:"编写展会现场运营方案:区域划分、人员排班、动线与签到、物料保障、对接流程与问题上报机制。",systemPrompt:"你是一位会展现场运营总监,编写可执行的现场运营方案。基于给定规模与场地,排班与点位具体到岗,不编造场馆固定设施数据。",userPromptTemplate:`请根据下面信息编写现场运营方案:功能区划分、岗位与排班、观众动线与签到分流、物料与设备保障、突发问题上报与处置流程、各组对接与值班表。
信息:
---
{{input}}
---`}),e({id:"analysis.ex-schedule",label:"活动日程排期",shortLabel:"活动日程",icon:"🗓️",tags:["会展","生成","日程"],allowedActions:["insert","append","comment","none"],defaultAction:"insert",temperature:.3,description:"把展期活动排成日程表:日期时段、活动名称、地点、负责人与备注,衔接合理留缓冲。",systemPrompt:"你是一位会展项目统筹,排清晰可执行的活动日程。时间照给定信息,场地与嘉宾不冲突,关键节点标提醒,不虚增活动。",userPromptTemplate:`请把下面展期活动排成日程表,表格:日期时段 | 活动名称 | 地点 | 负责人 | 备注。覆盖开幕式、论坛、签约、同期活动、撤展,衔接合理留缓冲,标注冲突风险。
活动信息:
---
{{input}}
---`}),e({id:"analysis.ex-booth-desc",label:"展位说明文案",shortLabel:"展位说明",icon:"🪧",tags:["会展","生成","展位"],allowedActions:["insert","append","replace","none"],defaultAction:"insert",temperature:.5,description:"写展位/展区说明文案:展示主题、展品亮点、互动体验与引导语,用于现场展板与导览。",systemPrompt:"你是一位会展展陈文案,写简洁有吸引力的展位说明。只用给定展品与主题信息,不夸大功效与参数,不编造证书资质。",userPromptTemplate:`请根据下面信息写展位/展区说明文案:展示主题一句话、展品亮点(分点)、互动体验介绍、参观引导语。简洁有吸引力,只用给定信息不夸大。
展位信息:
---
{{input}}
---`}),e({id:"analysis.ex-guest-reception",label:"嘉宾接待方案",shortLabel:"嘉宾接待",icon:"🤝",tags:["会展","生成","接待"],allowedActions:["insert","append","none"],defaultAction:"insert",temperature:.3,description:"编写重要嘉宾接待方案:接送机、行程、座次、陪同分工、餐饮住宿与礼仪要点,周到不失礼。",systemPrompt:"你是一位会展礼宾接待主管,编写周到细致的嘉宾接待方案。行程与人员照给定信息,座次与称谓规范,不编造嘉宾职务与抵离时间。",userPromptTemplate:`请根据下面信息编写嘉宾接待方案:抵离接送安排、当日行程时刻、座次与陪同分工、餐饮与住宿、礼仪与称谓要点、应急联系人。职务与时间照原文,缺则【待确认】。
嘉宾信息:
---
{{input}}
---`}),e({id:"analysis.ex-recruit-script",label:"招展话术",shortLabel:"招展话术",icon:"📞",tags:["会展","生成","话术"],allowedActions:["insert","append","replace","none"],defaultAction:"insert",temperature:.6,description:"整理招展电话/微信沟通话术:开场、价值切入、常见异议应答、促单与跟进,自然不套路。",systemPrompt:"你是一位资深会展招商,整理实战招展话术。只用给定展会与政策信息,价格照原文,异议应答讲实在理由,不承诺无法兑现的效果。",userPromptTemplate:`请根据下面展会与政策信息整理招展话术:开场自我介绍、价值切入、报价与优惠说明(数字照原文)、常见异议(太贵/没效果/再考虑)应答、促单与跟进话术。自然真诚不套路。
展会与政策:
---
{{input}}
---`}),e({id:"analysis.ex-promo-copy",label:"宣传推广文案",shortLabel:"宣传文案",icon:"📣",tags:["会展","生成","宣传"],allowedActions:["insert","append","replace","none"],defaultAction:"insert",temperature:.6,description:"写展会宣传推广文案:公众号推文、海报标语、短视频脚本与朋友圈,突出亮点不浮夸。",systemPrompt:"你是一位会展品牌文案,写有传播力的宣传文案。只用给定亮点与数据,数字照原文,不虚构展商规模与观众量,不堆砌空话。",userPromptTemplate:`请根据下面信息写展会宣传文案:公众号推文(标题+正文)、海报主标语3条、短视频脚本一条、朋友圈短文案3条。突出真实亮点,数字照原文,不浮夸。
信息:
---
{{input}}
---`}),e({id:"analysis.ex-press-release",label:"媒体新闻通稿",shortLabel:"新闻通稿",icon:"📰",tags:["会展","生成","媒体"],allowedActions:["insert","append","replace","none"],defaultAction:"insert",temperature:.4,description:"写展会新闻通稿:导语、规模与亮点、同期活动、嘉宾与成果、主办背景,客观规范可直接发媒体。",systemPrompt:"你是一位会展媒体宣传,写客观规范的新闻通稿。规模、嘉宾、成交数字一律照原文,缺则不写,不夸大、不编造引语与成果。",userPromptTemplate:`请根据下面信息写展会新闻通稿:导语(何时何地何展)、展会规模与亮点、同期活动、重要嘉宾与签约成果、主办方与展望。客观规范,数字照原文,不编造引语。
信息:
---
{{input}}
---`}),e({id:"analysis.ex-coop-proposal",label:"合作方案",shortLabel:"合作方案",icon:"🤝",tags:["会展","生成","合作"],allowedActions:["insert","append","none"],defaultAction:"insert",temperature:.4,description:"编写赞助/媒体/协办等合作方案:合作背景、权益与回报、合作形式与档位、对接与排期。",systemPrompt:"你是一位会展商务拓展,编写清晰对等的合作方案。权益与金额照给定信息,缺则【待商议】,不夸大曝光量与到会效果。",userPromptTemplate:`请根据下面信息编写合作方案:合作背景与契合点、合作形式(赞助/协办/媒体/资源置换)、权益与回报清单、合作档位与价值(数字照原文)、对接流程与排期。缺失写【待商议】。
信息:
---
{{input}}
---`}),e({id:"analysis.ex-budget-note",label:"展会预算说明",shortLabel:"预算说明",icon:"💰",tags:["会展","整理","预算"],allowedActions:["insert","append","comment","none"],defaultAction:"insert",temperature:.15,description:"把展会费用整理成预算说明:场租、搭建、宣传、人力、接待等分项金额、占比与合计,提示易漏项。",systemPrompt:"你是一位会展财务,整理清晰的展会预算说明。金额照原文,合计与占比先列原文数字再计算,提示常见易漏项,不编造报价。本说明仅供内部测算参考,不构成财务或税务意见,最终以正式报价与财务核定为准。",userPromptTemplate:`请把下面费用整理成展会预算说明,表格:费用项目 | 金额 | 占比 | 备注。分场地/搭建/宣传/人力/接待/物料/应急等类。合计与占比先列原文数字再算,提示易漏项(保险/加班/运输/拆除)。结尾注明:本测算仅供内部参考,以正式报价与财务核定为准。
费用信息:
---
{{input}}
---`}),e({id:"analysis.ex-safety-plan",label:"安全应急方案",shortLabel:"安全应急",icon:"🧯",tags:["会展","生成","安全"],allowedActions:["insert","append","comment","none"],defaultAction:"insert",temperature:.3,description:"编写展会安全应急方案框架:消防疏散、大客流、用电、医疗、极端天气等风险的预防与处置分工。",systemPrompt:"你是一位会展安全管理负责人,编写实用的安全应急方案框架。基于给定场景列风险,处置具体、责任到人。本方案仅供策划参考,不替代消防、公安等法定审批与专业评估。",userPromptTemplate:`请根据下面展会场景编写安全应急方案框架:主要风险(消防疏散/大客流踩踏/用电故障/医疗急救/极端天气/治安)、每项预防与处置步骤、责任岗位与联系人、疏散与集合点、应急物资清单。提醒须经消防公安等法定审批。
展会场景:
---
{{input}}
---`}),e({id:"analysis.ex-post-report",label:"展后总结报告",shortLabel:"展后总结",icon:"📊",tags:["会展","生成","总结"],allowedActions:["insert","append","none"],defaultAction:"insert",temperature:.4,description:"把展会数据与情况写成展后总结报告:规模与数据、亮点、问题与改进、效益评估,客观可复盘。",systemPrompt:"你是一位会展项目经理,写客观可复盘的展后总结。展商数、观众数、成交额等一律照原文,缺则注明未统计,不夸大成效、不编造数据。",userPromptTemplate:`请根据下面信息写展后总结报告:展会概况、关键数据(展商/观众/成交/媒体,照原文)、做得好的亮点、存在问题与原因、改进建议、整体效益评估。数字照原文,缺则注明未统计。
展会信息:
---
{{input}}
---`}),e({id:"analysis.ex-contract-review",label:"参展/搭建合同审查",shortLabel:"合同审查",icon:"📑",tags:["会展","核查","合同","check"],allowedActions:["comment","link-comment","append","none"],defaultAction:"comment",temperature:.15,description:"审查参展、搭建、场馆等合同对己方不利之处:付款与退展、面积变更、违约、安全责任与押金退还。",systemPrompt:"你是一位会展法务,审查合同对己方的风险。命中片段须原文逐字、反引号包裹;不确定标「待人工核实」。仅辅助审阅,不替代执业律师与法定审批。",userPromptTemplate:`请审查下面会展相关合同,关注:付款节点与退展退款、展位面积/位置变更、布撤展时间与超时费、押金退还条件、安全与意外责任划分、违约责任是否对等、不可抗力。
## 风险/不利条款 (若无写"未发现明显问题")
- 命中片段:\`原文逐字片段\`
- 问题:
- 建议:
合同:
---
{{input}}
---`}),e({id:"analysis.ex-doc-polish",label:"会展文稿润色规范",shortLabel:"文稿润色",icon:"🖋️",tags:["会展","改写","润色"],allowedActions:["replace","append","comment","none"],defaultAction:"replace",defaultInputSource:i,temperature:.35,description:"把会展通知、致辞、说明等文稿润色为规范得体的表达:措辞专业、语气得体、行文流畅,保留原意。",systemPrompt:"你是一位会展文秘,把文稿润色得规范、专业、得体。只在原意范围内修改,不增删事实与数字,不编造内容,去除浮夸与口语。",userPromptTemplate:`请把下面会展文稿润色为规范得体的版本:措辞专业、语气得体、行文流畅、去除浮夸与口水话,保留全部事实与数字不变。直接给修改后正文。
原文:
---
{{input}}
---`}),e({id:"analysis.ex-info-extract",label:"展会信息抽取",shortLabel:"信息抽取",icon:"🔎",tags:["会展","抽取","结构化"],allowedActions:["none","comment","append"],defaultAction:"none",defaultOutputFormat:"json",temperature:.1,description:"从展会资料/合同/邀请函中抽取关键信息为结构化JSON:展会名称、时间地点、面积、价格、联系人等。",systemPrompt:"你是一位会展信息整理员,从文本中抽取关键信息。严格输出JSON,只用原文出现的信息,找不到的字段留空字符串或空数组,不编造、不推测。",userPromptTemplate:`请从下面文本抽取展会关键信息,严格输出JSON,找不到留空,不编造。结构:
{
  "exhibition_name": "",
  "dates": "",
  "venue": "",
  "organizer": "",
  "booth_area": "",
  "booth_price": "",
  "deadlines": [],
  "contacts": [{"name":"","phone":"","role":""}],
  "notes": ""
}
文本:
---
{{input}}
---`})]);function l(n=[]){const s=new Set(n.map(t=>t&&t.id));return[...n,...o.filter(t=>t&&!s.has(t.id))]}const p={EXHIBITION_BUILTIN_ASSISTANTS:o};export{o as EXHIBITION_BUILTIN_ASSISTANTS,p as default,l as mergeExhibitionIntoBuiltins};
