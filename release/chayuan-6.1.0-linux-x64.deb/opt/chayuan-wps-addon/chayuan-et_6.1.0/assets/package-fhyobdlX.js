const o="6.1.0",s={version:o};export{s as p};
