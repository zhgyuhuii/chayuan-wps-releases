const e=""+new URL("qrcode-DyYLeFS7.png",import.meta.url).href;export{e as default};
